import time
import os

print(os.path.abspath(__file__))

time.sleep(2000)